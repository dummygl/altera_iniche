// -------------------------------------------------------------------------
// -------------------------------------------------------------------------
//
// Revision Control Information
//
// $RCSfile$
// $Source$
//
// $Revision$
// $Date$
// Check in by : $Author$
// Author      : Arul Paniandi
//
// Project     : Triple Speed Ethernet - 10/100/1000 MAC
//
// Description : 
//
// UCOSII/InterNiche driver functions
//
// 
// Legal Notice: (C)2006 Altera Corporation. All rights reserved. Your use 
// of Altera Corporation's design tools, logic functions and other software 
// and tools, and its AMPP partner logic functions, and any output files 
// any of the foregoing (including device programming or simulation files),
// and any associated documentation or information are expressly subject to
// the terms and conditions of the Altera Program License Subscription 
// Agreement, Altera MegaCore Function License Agreement, or other 
// applicable license agreement, including, without limitation, that your 
// use is for the sole purpose of programming logic devices manufactured by
// Altera and sold by Altera or its authorized distributors.  Please refer 
//to the applicable agreement for further details.
//
// -------------------------------------------------------------------------
// -------------------------------------------------------------------------
#ifdef ALT_INICHE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <io.h>
#include <os_cpu.h>
#include "ipport.h"


#ifdef UCOS_II  
#include <ucos_ii.h>
#endif

#include "in_utils.h"
#include "netbuf.h"
#include "net.h"
#include "q.h"
#include "ether.h"
#include "system.h"
#include "alt_types.h"

#include "altera_avalon_timer_regs.h"
#include "altera_avalon_sgdma_descriptor.h"
#include "altera_avalon_tse.h"

#include "sys/alt_irq.h"
#include "sys/alt_cache.h"

#include "triple_speed_ethernet_regs.h"
#include "iniche/triple_speed_ethernet_iniche.h"
#include "iniche/ins_tse_mac.h"

#include "socket.h"



/* Task includes */
//#include "tse_system.h"
//  if included in the Syslib folder
//  #include "iniche/tse_system.h"

#include "ipport.h"
#include "tcpapp.h"

#ifndef ALT_INICHE
#include "osport.h"
#endif


#ifdef ALT_INICHE
#include <errno.h>
#include "alt_iniche_dev.h"
#endif

#ifdef ALTERA_TSE_IRQ_R

    extern int ALTERA_TSE_IRQ_R(void * context, u_long intnum);

#endif



ins_tse_info tse[MAXNETS];
extern alt_tse_system_info tse_mac_device[MAXNETS];


#if ALTERA_TSE_QOS_TIMER_OPTION  
#define ALARM_ENABLE 0x01
static void timer_interrupts(void* context, alt_u32 id);
#endif

#ifdef ALT_INICHE


/* @Function Description: TSE MAC Driver Open/Initialization routine
 * @API TYPE: Public
 * @Param p_dec     pointer to TSE device instance
 * @Return NULL
 */

error_t triple_speed_ethernet_init(
    alt_iniche_dev              *p_dev)
{
    prep_tse_mac(p_dev->if_num);

#ifdef PRINTIF
    printf("triple_speed_ethernet_init %d\n", p_dev->if_num);
#endif    

    return SUCCESS;
}
#endif /* ALT_INICHE */



/* @Function Description: TSE MAC Driver Open/Registration routine
 * @API TYPE: Internal
 * @Param index     index of the NET structure associated with TSE instance
 * @Return next index of NET
 */
int prep_tse_mac(int index)
{
    NET ifp;
    dprintf("prep_tse_mac %d\n", index);
    {
        tse[index].sem = 0; /*Tx IDLE*/
        tse[index].tse = &tse_mac_device[index];
    
        ifp = nets[index];
        ifp->n_mib->ifAdminStatus = ALTERA_TSE_ADMIN_STATUS_DOWN; /* status = down */
        ifp->n_mib->ifOperStatus =  ALTERA_TSE_ADMIN_STATUS_DOWN;   
        ifp->n_mib->ifLastChange =  cticks * (100/TPS);
        ifp->n_mib->ifPhysAddress = (u_char*)tse[index].mac_addr;
        ifp->n_mib->ifDescr =       (u_char*)"Altera TSE MAC ethernet";
        ifp->n_lnh =                ETHHDR_SIZE; /* ethernet header size. was:14 */
        ifp->n_hal =                ALTERA_TSE_HAL_ADDR_LEN;  /* hardware address length */
        ifp->n_mib->ifType =        ETHERNET;   /* device type */
        ifp->n_mtu =                ALTERA_TSE_MAX_MTU_SIZE;  /* max frame size */
    
        /* install our hardware driver routines */
        ifp->n_init =       tse_mac_init;
        ifp->pkt_send =     NULL;
        ifp->raw_send =     tse_mac_raw_send;
        ifp->n_close =      tse_mac_close;
        ifp->n_stats =      (void(*)(void *, int))tse_mac_stats; 
#ifdef IP_MULTICAST
	{
          extern int mcastlist(struct in_multi *);
          ifp->n_mcastlist = mcastlist;
	}
#endif
    
        ifp->n_flags |= (NF_NBPROT | NF_IEEE48 |
#ifdef IP_V6
			 NF_IPV6 |
#endif
			 NF_MCAST | NF_BCAST);
    
        nets[index]->n_mib->ifPhysAddress = (u_char*)tse[index].mac_addr;   /* ptr to MAC address */
    
    #ifdef ALT_INICHE
        /* get the MAC address. */
        get_mac_addr(ifp, (unsigned char *)tse[index].mac_addr);
    #endif /* ALT_INICHE */
    
        /* set cross-pointers between iface and tse structs */
        tse[index].index = index;
        tse[index].netp = ifp;
        ifp->n_local = (void*)(&tse[index]);
    
        index++;
   }
 
   return index;
}



/* @Function Description: TSE MAC Initialization routine. This function opens the
 *                        device handle, configure the callback function and interrupts ,
 *                        for SGDMA TX and SGDMA RX block associated with the TSE MAC,
 *                        Initialize the MAC Registers for the RX FIFO and TX FIFO
 *                        threshold watermarks, initialize the tse device structure,
 *                        set the MAC address of the device and enable the MAC   
 * 
 * @API TYPE: Internal
 * @Param iface index of the NET structure associated with TSE instance
 * @Return 0 if ok, else -1 if error
 */
int tse_mac_init(int iface)
{
   int dat;
   int is1000, duplex, result, x;
   int status = SUCCESS;
   
   NET ifp;
   alt_sgdma_dev *sgdma_tx_dev;
   alt_sgdma_dev *sgdma_rx_dev;
   alt_tse_system_info* tse_hw = (alt_tse_system_info *) tse[iface].tse;
   
  
   dprintf("[tse_mac_init]\n");
#ifdef PRINTIF
    printf("tse_mac_init %d\n", iface);
#endif    

    if (tse_hw->ext_desc_mem == 1)
    {
       int i;
    
        tse[iface].desc = (alt_sgdma_descriptor *) tse_hw->desc_mem_base;   
        //Clearing SGDMA desc Memory
        for (i = 0 ; i < 256; i ++)
            IOWR(tse_hw->desc_mem_base,i,0);
        printf("SGDMA desc memory cleared \n");
    }
    else
    {
        unsigned char *temp_desc = (unsigned char *)alt_uncached_malloc((3+ALTERA_TSE_SGDMA_RX_DESC_CHAIN_SIZE)* ALTERA_AVALON_SGDMA_DESCRIPTOR_SIZE);
    
        while ((((alt_u32)temp_desc) % ALTERA_AVALON_SGDMA_DESCRIPTOR_SIZE) != 0)
        {
            temp_desc++;
        }
        tse[iface].desc = (alt_sgdma_descriptor *) temp_desc;
    
    }
  

   
   //Setting Desc Memory Pointer
   tse[iface].currdescriptor_ptr =  &tse[iface].desc[ALTERA_TSE_FIRST_RX_SGDMA_DESC_OFST];
   tse[iface].nextdescriptor_ptr = (alt_sgdma_descriptor *) IORD_ALTERA_TSE_SGDMA_DESC_NEXT(tse[iface].currdescriptor_ptr);

   tse[iface].desc_pointer = tse[iface].currdescriptor_ptr;

   for(tse[iface].chain_loop = 0;tse[iface].chain_loop < ALTERA_TSE_SGDMA_RX_DESC_CHAIN_SIZE; tse[iface].chain_loop++)
   {  
      tse[iface].desc_pointer->status&=~ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_TERMINATED_BY_EOP_MSK;
      tse[iface].desc_pointer = (alt_sgdma_descriptor *)IORD_ALTERA_TSE_SGDMA_DESC_NEXT(tse[iface].desc_pointer);
   }
   
   tse[iface].chain_loop = 0; 
   tse[iface].desc_pointer = tse[iface].currdescriptor_ptr;   
   
     
   /* Get the Rx and Tx SGDMA addresses */
   sgdma_tx_dev = alt_avalon_sgdma_open(tse_hw->tse_sgdma_tx);
   if(!sgdma_tx_dev) {
      dprintf("[triple_speed_ethernet_init] Error opening TX SGDMA\n");
      return ENP_RESOURCE;
   }
  
   sgdma_rx_dev = alt_avalon_sgdma_open(tse_hw->tse_sgdma_rx);
   if(!sgdma_rx_dev) {
      dprintf("[triple_speed_ethernet_init] Error opening RX SGDMA\n");
      return ENP_RESOURCE;
   }

   /* Initialize mtip_mac_trans_info structure with values from <system.h>*/

   tse_mac_initTransInfo2(&tse[iface].mi, (int)tse_hw->tse_mac_base,
                                   (unsigned int)sgdma_tx_dev,            
                                   (unsigned int)sgdma_rx_dev,
                                   0);

   IOWR_ALTERA_AVALON_SGDMA_CONTROL(tse[iface].mi.rx_sgdma->base,ALTERA_AVALON_SGDMA_CONTROL_SOFTWARERESET_MSK);
   IOWR_ALTERA_AVALON_SGDMA_CONTROL(tse[iface].mi.rx_sgdma->base, 0x0);
   
   tse[iface].interruptNR = tse_hw->tse_sgdma_rx_irq;
   ifp = tse[iface].netp;

   /* reset the PHY if necessary */   
   result = getPHYSpeed(tse[iface].mi.base);
   is1000 = (result >> 1) & 0x01;
   duplex = result & 0x01;
    
   /* reset the mac */ 
   IOWR_ALTERA_TSEMAC_CMD_CONFIG(tse[iface].mi.base,
                             mmac_cc_SW_RESET_mask | 
                             mmac_cc_TX_ENA_mask | 
                             mmac_cc_RX_ENA_mask);
  
   x=0;
   while(IORD_ALTERA_TSEMAC_CMD_CONFIG(tse[iface].mi.base) & 
         ALTERA_TSEMAC_CMD_SW_RESET_MSK) {
     if( x++ > 10000 ) {
       break;
     }
   }
  
   if(x >= 10000) {
     printf("TSEMAC SW reset bit never cleared!\n");
   }

   dat = IORD_ALTERA_TSEMAC_CMD_CONFIG(tse[iface].mi.base);
   if( (dat&0x03)  != 0 ) {
     printf("WARN: RX/TX not disabled after reset... missing PHY clock? CMD_CONFIG=0x%08x\n", dat);
   } 
   else {
     printf("OK, x=%d, CMD_CONFIG=0x%08x\n", x, dat);
   }
  
  if(tse_hw->use_shared_fifo == 1)
  {
      IOWR_ALTERA_MULTI_CHAN_FIFO_SEC_FULL_THRESHOLD(tse_hw->shared_fifo_ctrl_base,0);
      IOWR_ALTERA_MULTI_CHAN_FIFO_SEC_EMPTY_THRESHOLD(tse_hw->shared_fifo_ctrl_base,0);
      IOWR_ALTERA_MULTI_CHAN_FIFO_ALMOST_FULL_THRESHOLD(tse_hw->shared_fifo_ctrl_base,0);
      IOWR_ALTERA_MULTI_CHAN_FIFO_ALMOST_EMPTY_THRESHOLD(tse_hw->shared_fifo_ctrl_base,0);
  }
  else
  {
      /* Initialize MAC registers */
      
      IOWR_ALTERA_TSEMAC_FRM_LENGTH(tse[iface].mi.base, ALTERA_TSE_MAC_MAX_FRAME_LENGTH); 
      IOWR_ALTERA_TSEMAC_RX_ALMOST_EMPTY(tse[iface].mi.base, 8);
      IOWR_ALTERA_TSEMAC_RX_ALMOST_FULL(tse[iface].mi.base, 8);
      IOWR_ALTERA_TSEMAC_TX_ALMOST_EMPTY(tse[iface].mi.base, 8);
      IOWR_ALTERA_TSEMAC_TX_ALMOST_FULL(tse[iface].mi.base,  3);
      IOWR_ALTERA_TSEMAC_TX_SECTION_EMPTY(tse[iface].mi.base, tse_hw->tse_tx_depth - 16); //1024/4;  
      IOWR_ALTERA_TSEMAC_TX_SECTION_FULL(tse[iface].mi.base,  0); //32/4; // start transmit when there are 48 bytes
      IOWR_ALTERA_TSEMAC_RX_SECTION_EMPTY(tse[iface].mi.base, tse_hw->tse_rx_depth - 16); //4000/4);
      IOWR_ALTERA_TSEMAC_RX_SECTION_FULL(tse[iface].mi.base,  0);
  }
/* Enable TX shift 16 for removing two bytes from the start of all transmitted frames */
 
if((ETHHDR_BIAS !=0) && (ETHHDR_BIAS !=2))
{
    printf("[tse_mac_init] Error: Unsupported Ethernet Header Bias Value, %d\n",ETHHDR_BIAS);
    return ENP_PARAM;
}
 
if(ETHHDR_BIAS == 0)
{
 
    alt_32 temp_reg;
    
    temp_reg = IORD_ALTERA_TSEMAC_TX_CMD_STAT(tse[iface].mi.base) & (~ALTERA_TSEMAC_TX_CMD_STAT_TXSHIFT16_MSK);
    IOWR_ALTERA_TSEMAC_TX_CMD_STAT(tse[iface].mi.base,temp_reg);
 
      /* 
       * check if the MAC supports the 16-bit shift option allowing us
       * to send BIASed frames without copying. Used by the send function later. 
       */
      if(IORD_ALTERA_TSEMAC_TX_CMD_STAT(tse[iface].mi.base) & 
         ALTERA_TSEMAC_TX_CMD_STAT_TXSHIFT16_MSK) {
         tse[iface].txShift16OK = 1;
         printf("[tse_mac_init] Error: Incompactible %d value with TX_CMD_STAT register return TxShift16 value. \n",ETHHDR_BIAS);
        return ENP_LOGIC;
      } else {
        tse[iface].txShift16OK = 0;
      }
   
  /*Enable RX shift 16 for allignment of all received frames on 16-bit start address */   
    temp_reg = IORD_ALTERA_TSEMAC_RX_CMD_STAT(tse[iface].mi.base) & (~ALTERA_TSEMAC_RX_CMD_STAT_RXSHIFT16_MSK);
    IOWR_ALTERA_TSEMAC_RX_CMD_STAT(tse[iface].mi.base,temp_reg);
   
  /* check if the MAC supports the 16-bit shift option at the RX CMD STATUS Register  */ 
  if(IORD_ALTERA_TSEMAC_RX_CMD_STAT(tse[iface].mi.base) & ALTERA_TSEMAC_RX_CMD_STAT_RXSHIFT16_MSK)
  {
    tse[iface].rxShift16OK = 1;
    printf("[tse_mac_init] Error: Incompactible %d value with RX_CMD_STAT register return RxShift16 value. \n",ETHHDR_BIAS);
    return ENP_LOGIC;
    } else {
    tse[iface].rxShift16OK = 0;
  }
}
 
if(ETHHDR_BIAS == 2)
{
IOWR_ALTERA_TSEMAC_TX_CMD_STAT(tse[iface].mi.base,ALTERA_TSEMAC_TX_CMD_STAT_TXSHIFT16_MSK);
 
  /*
   * check if the MAC supports the 16-bit shift option allowing us
   * to send BIASed frames without copying. Used by the send function later.
   */
  if(IORD_ALTERA_TSEMAC_TX_CMD_STAT(tse[iface].mi.base) &
     ALTERA_TSEMAC_TX_CMD_STAT_TXSHIFT16_MSK) {
    tse[iface].txShift16OK = 1;
  } else {
    tse[iface].txShift16OK = 0;
    printf("[tse_mac_init] Error: Incompatible %d value with TX_CMD_STAT register return TxShift16 value. \n",ETHHDR_BIAS);
    return ENP_LOGIC;
 }
  
  /* Enable RX shift 16 for alignment of all received frames on 16-bit start address */
 
  IOWR_ALTERA_TSEMAC_RX_CMD_STAT(tse[iface].mi.base,ALTERA_TSEMAC_RX_CMD_STAT_RXSHIFT16_MSK);
 
  /* check if the MAC supports the 16-bit shift option at the RX CMD STATUS Register  */ 
  if(IORD_ALTERA_TSEMAC_RX_CMD_STAT(tse[iface].mi.base) & ALTERA_TSEMAC_RX_CMD_STAT_RXSHIFT16_MSK)
  {
    tse[iface].rxShift16OK = 1;
  } else {
    tse[iface].rxShift16OK = 0;
    printf("[tse_mac_init] Error: Incompatible %d value with RX_CMD_STAT register return RxShift16 value. \n",ETHHDR_BIAS);
    return ENP_LOGIC;
  }
 
}
  /* enable MAC */
 
  dat = ALTERA_TSEMAC_CMD_TX_ENA_MSK       |
        ALTERA_TSEMAC_CMD_RX_ENA_MSK       |
        mmac_cc_RX_ERR_DISCARD_mask        |
#if ENABLE_PHY_LOOPBACK || IP_MULTICAST
        ALTERA_TSEMAC_CMD_PROMIS_EN_MSK    |     // promiscuous mode
#endif
#if ENABLE_PHY_LOOPBACK
        ALTERA_TSEMAC_CMD_LOOPBACK_MSK     |     // promiscuous mode
#endif
        ALTERA_TSEMAC_CMD_TX_ADDR_INS_MSK  |
        ALTERA_TSEMAC_CMD_RX_ERR_DISC_MSK;  /* automatically discard frames with CRC errors */
    

    
  if(is1000) {
    dat |= ALTERA_TSEMAC_CMD_ETH_SPEED_MSK;
  }    
  
  if(duplex == 0) {
    dat |= ALTERA_TSEMAC_CMD_HD_ENA_MSK;
  }
          
  IOWR_ALTERA_TSEMAC_CMD_CONFIG(tse[iface].mi.base, dat);
  printf("\nMAC post-initialization: CMD_CONFIG=0x%08x\n", 
    IORD_ALTERA_TSEMAC_CMD_CONFIG(tse[iface].mi.base));
                                
#ifdef ALT_INICHE
   /* Set the MAC address */  
   IOWR_ALTERA_TSEMAC_MAC_0(tse[iface].mi.base,
                           ((int)((unsigned char) tse[iface].mac_addr[0]) | 
                            (int)((unsigned char) tse[iface].mac_addr[1] <<  8) |
                            (int)((unsigned char) tse[iface].mac_addr[2] << 16) | 
                            (int)((unsigned char) tse[iface].mac_addr[3] << 24)));
  
   IOWR_ALTERA_TSEMAC_MAC_1(tse[iface].mi.base, 
                           (((int)((unsigned char) tse[iface].mac_addr[4]) | 
                             (int)((unsigned char) tse[iface].mac_addr[5] <<  8)) & 0xFFFF));
   
#else /* not ALT_INICHE */

   /* Set the MAC address */  
   IOWR_ALTERA_TSEMAC_MAC_0(tse[iface].mi.base,
                           ((int)(0x00)       | 
                            (int)(0x07 <<  8) |
                            (int)(0xAB << 16) | 
                            (int)(0xF0 << 24)));

   IOWR_ALTERA_TSEMAC_MAC_1(tse[iface].mi.base, 
                           (((int)(0x0D)      | 
                             (int)(0xBA <<  8)) & 0xFFFF));


   /* Set the mac address in the tse struct */
   tse[iface].mac_addr[0] = 0x00;
   tse[iface].mac_addr[1] = 0x07;
   tse[iface].mac_addr[2] = 0xAB;
   tse[iface].mac_addr[3] = 0xF0;
   tse[iface].mac_addr[4] = 0x0D;
   tse[iface].mac_addr[5] = 0xBA;

#endif /* not ALT_INICHE */

   /* status = UP */ 
   nets[iface]->n_mib->ifAdminStatus = ALTERA_TSE_ADMIN_STATUS_UP;    
   nets[iface]->n_mib->ifOperStatus =  ALTERA_TSE_ADMIN_STATUS_UP;
   
   alt_avalon_sgdma_register_callback(
        tse[iface].mi.rx_sgdma,
#ifndef ALTERA_TSE_IRQ_R
        (alt_avalon_sgdma_callback)&tse_sgdmaRx_isr,
#else
        (alt_avalon_sgdma_callback)&ALTERA_TSE_IRQ_R,
#endif
        (alt_u16)ALTERA_TSE_SGDMA_INTR_MASK,
        (void*)(&tse[iface]));
    
  // optionally turn on the timer ISR to ensure QoS of the packet in the data path
  // the timer option along with the timer timeout period is defined in triple_speed_ethernet_iniche.h
#if ALTERA_TSE_QOS_TIMER_OPTION  
  tse[iface].alarmflags = 0;
  alt_irq_register(HIGH_RES_TIMER_IRQ, (void*)(&tse[iface]), timer_interrupts);
  IOWR_ALTERA_AVALON_TIMER_PERIODL(HIGH_RES_TIMER_BASE, TIME_OUT);// timer interrupt period is 100us
  IOWR_ALTERA_AVALON_TIMER_PERIODH(HIGH_RES_TIMER_BASE, 0x00);
  IOWR_ALTERA_AVALON_TIMER_CONTROL(HIGH_RES_TIMER_BASE, 7); 

#endif /* ALTERA_TSE_QOS_TIMER_OPTION */
      
  status = tse_sgdma_read_init(&tse[iface]);
  
  return status;
}



/* @Function Description -  TSE transmit API to send data to the MAC
 *                          
 * 
 * @API TYPE - Public
 * @param  net  - NET structure associated with the TSE MAC instance
 * @param  data - pointer to the data payload
 * @param  data_bytes - number of bytes of the data payload to be sent to the MAC
 * @return SUCCESS if success, else a negative value
 */

int tse_mac_raw_send(NET net, char * data, unsigned data_bytes)
{
   int result,i,tx_length;
   unsigned len = data_bytes;
   ins_tse_info* tse_ptr = (ins_tse_info*) net->n_local;
   alt_tse_system_info* tse_hw = (alt_tse_system_info *) tse_ptr->tse;
   
   tse_mac_trans_info *mi;
   unsigned int* ActualData;
   int cpu_sr;
   /* Intermediate buffers used for temporary copy of frames that cannot be directrly DMA'ed*/
   char buf2[1560];

   OS_ENTER_CRITICAL();
   mi = &tse_ptr->mi;
   
   if(tse_ptr->sem!=0) /* Tx is busy*/
   {
      dprintf("raw_send CALLED AGAIN!!!\n");
      OS_EXIT_CRITICAL();
      return ENP_RESOURCE;
   }
 
   tse_ptr->sem = 1;  

   
   if (((unsigned int)data & 0x03) == 0) 
   { 
      /* 32-bit aligned start, then header starts ETHHDR_BIAS later => 16 bit shift is ok */    
      ActualData = (unsigned int*)data;  /* base driver will detect 16-bit shift. */
   } 
   else
   {
      /* 
       * Copy data to temporary buffer <buf2>. This is done because of allignment 
       * issues. The SGDMA cannot copy the data directly from (data + ETHHDR_BIAS)
       * because it needs a 32-bit alligned address space. 
       */
      for(i=0;i<len;i++) {
         buf2[i] = IORD_8DIRECT(&data[i], 0);
      }
      ActualData = (unsigned int*)buf2;
   }  
   
     // clear bit-31 before passing it to SGDMA Driver
    ActualData = (unsigned int*)alt_remap_cached ((volatile void*) ActualData, 4);
    
   /* Write data to Tx FIFO using the DMA */
   if(tse_hw->use_shared_fifo == 1)
   {
        while(IOADDR_ALTERA_MULTI_CHAN_FILL_LEVEL(tse_hw->shared_fifo_stat_base) < ALTERA_TSE_MIN_MTU_SIZE);
        /* make sure there is room in the FIFO.        */
        alt_avalon_sgdma_construct_mem_to_stream_desc(
           (alt_sgdma_descriptor *) &tse_ptr->desc[ALTERA_TSE_FIRST_TX_SGDMA_DESC_OFST], // descriptor I want to work with
           (alt_sgdma_descriptor *) &tse_ptr->desc[ALTERA_TSE_SECOND_TX_SGDMA_DESC_OFST],// pointer to "next"
           (alt_u32*)ActualData,                     // starting read address
           (len),                                  // # bytes
           0,                                        // don't read from constant address
           1,                                        // generate sop
           1,                                        // generate endofpacket signal
           0);                                       // atlantic channel (don't know/don't care: set to 0)
                  
    
        tx_length = tse_mac_sTxWrite(mi,tse_ptr->desc);
        result = 0;
   }
   else if( len > ALTERA_TSE_MIN_MTU_SIZE ) {    
   
       /* make sure there is room in the FIFO.        */
        alt_avalon_sgdma_construct_mem_to_stream_desc(
           (alt_sgdma_descriptor *) &tse_ptr->desc[ALTERA_TSE_FIRST_TX_SGDMA_DESC_OFST], // descriptor I want to work with
           (alt_sgdma_descriptor *) &tse_ptr->desc[ALTERA_TSE_SECOND_TX_SGDMA_DESC_OFST],// pointer to "next"
           (alt_u32*)ActualData,                     // starting read address
           (len),                                  // # bytes
           0,                                        // don't read from constant address
           1,                                        // generate sop
           1,                                        // generate endofpacket signal
           0);                                       // atlantic channel (don't know/don't care: set to 0)
                  
    
       tx_length = tse_mac_sTxWrite(mi,tse_ptr->desc);
       result = 0;

   } else {
       result = -3;
   }
      

   if(result < 0)   /* SGDMA not available */
   {
      dprintf("raw_send() SGDMA not available, ret=%d, len=%d\n",result, len);
      net->n_mib->ifOutDiscards++;
      tse_ptr->sem = 0;

      OS_EXIT_CRITICAL();
      return SEND_DROPPED;   /* ENP_RESOURCE and SEND_DROPPED have the same value! */
   }
   else   /* = 0, success */
   {
      net->n_mib->ifOutOctets += data_bytes;
      /* we dont know whether it was unicast or not, we count both in <ifOutUcastPkts> */
      net->n_mib->ifOutUcastPkts++;
      tse_ptr->sem = 0;

      OS_EXIT_CRITICAL();
      return SUCCESS;  /*success */
   } 
   
}



/* @Function Description -  timer ISR for TSE Driver for ensuring QoS
 *                          
 * 
 * @API TYPE - callback
 * @param  context  context of the alarm timer
 * @return alarm ticks
 */

#if ALTERA_TSE_QOS_TIMER_OPTION  

static void timer_interrupts(void* context, alt_u32 id)
{
  ins_tse_info* tse_ptr = context;
    
    
  tse_ptr->desc_pointer2 = tse_ptr->currdescriptor_ptr;


  if(alarmflags&ALARM_ENABLE) {
        for(tse_ptr->chain_loop2 = 0;tse_ptr->chain_loop2 < ALTERA_TSE_SGDMA_RX_DESC_CHAIN_SIZE; tse_ptr->chain_loop2++)
          { 
            if ( ~(IORD_ALTERA_AVALON_SGDMA_STATUS(tse_ptr->mi.rx_sgdma->base) & ALTERA_AVALON_SGDMA_STATUS_BUSY_MSK) ) 
                if (~((IORD_ALTERA_TSE_SGDMA_DESC_STATUS((alt_sgdma_descriptor *)IORD_ALTERA_TSE_SGDMA_DESC_NEXT(tse_ptr->desc_pointer))) & 
                     ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_TERMINATED_BY_EOP_MSK)) {
                            
                              tse_ptr->desc_pointer2->next = (alt_sgdma_descriptor *) &tse_ptr->desc[ALTERA_TSE_SGDMA_RX_DESC_CHAIN_SIZE + ALTERA_TSE_SECOND_RX_SGDMA_DESC_OFST - 1];
                            break;
                     }
                tse_ptr->desc_pointer2 = (alt_sgdma_descriptor *)IORD_ALTERA_TSE_SGDMA_DESC_NEXT(tse_ptr->desc_pointer);
          }
        if((IORD_ALTERA_AVALON_SGDMA_STATUS(tse_ptr->mi.rx_sgdma->base) & 
            ALTERA_AVALON_SGDMA_STATUS_CHAIN_COMPLETED_MSK ))
        {
              tse_mac_rcv(context);
              
              IOWR_ALTERA_AVALON_SGDMA_CONTROL(tse_ptr->mi.rx_sgdma->base, 0x00);
              
                if ((rcvdq.q_len) > 0)
                {
                    SignalPktDemux();
                }
             
              IOWR_ALTERA_AVALON_SGDMA_CONTROL(tse_ptr->mi.rx_sgdma->base, ALTERA_TSE_SGDMA_INTR_MASK);
               
              if((IORD_ALTERA_AVALON_SGDMA_STATUS(tse_ptr->mi.rx_sgdma->base) & 
                  ALTERA_AVALON_SGDMA_STATUS_CHAIN_COMPLETED_MSK ))
              {
                tse_mac_aRxRead( &tse_ptr->mi, tse_ptr->currdescriptor_ptr);
                tse_ptr->chain_loop = 0;
              }
                       
        }
            
         
         
  }
    IOWR_ALTERA_AVALON_TIMER_STATUS(HIGH_RES_TIMER_BASE, 0);
    
}



#endif /* ALTERA_TSE_QOS_TIMER_OPTION  */



/* @Function Description -  TSE Driver SGDMA RX ISR callback function
 *                          
 * 
 * @API TYPE - callback
 * @param  context  - context of the TSE MAC instance
 * @param  intnum - temporary storage
 */
int tse_sgdmaRx_isr(void * context, u_long intnum)
{

   ins_tse_info* tse_ptr = (ins_tse_info *) context;


#if ALTERA_TSE_QOS_TIMER_OPTION  
    tse_ptr->alarmflags&=~ALARM_ENABLE;
#endif
 
  tse_mac_rcv((ins_tse_info *) context);
  
  IOWR_ALTERA_AVALON_SGDMA_CONTROL( tse_ptr->mi.rx_sgdma->base, 0x00);
  
  if ((rcvdq.q_len) > 0)
  {
    SignalPktDemux();
  }
 
  IOWR_ALTERA_AVALON_SGDMA_CONTROL(tse_ptr->mi.rx_sgdma->base, ALTERA_TSE_SGDMA_INTR_MASK);
   
  if((IORD_ALTERA_AVALON_SGDMA_STATUS(tse_ptr->mi.rx_sgdma->base) & 
      ALTERA_AVALON_SGDMA_STATUS_CHAIN_COMPLETED_MSK ))
  {
    tse_mac_aRxRead( &tse_ptr->mi, tse_ptr->currdescriptor_ptr);
    tse_ptr->chain_loop = 0;
  }
  
  return SUCCESS;
}



/* @Function Description -  Init and setup SGDMA Descriptor chain
 *                          
 * 
 * @API TYPE - Internal
 * @return SUCCESS on success 
 */
int tse_sgdma_read_init(ins_tse_info* tse_ptr)
{     
    alt_u32 *uncached_packet_payload;
  
  for(tse_ptr->chain_loop = 0; tse_ptr->chain_loop < ALTERA_TSE_SGDMA_RX_DESC_CHAIN_SIZE; tse_ptr->chain_loop++)
  { 
    tse_ptr->pkt_array[tse_ptr->chain_loop] = pk_alloc(ALTERA_TSE_PKT_INIT_LEN+4);
    
    if (!tse_ptr->pkt_array[tse_ptr->chain_loop])   /* couldn't get a free buffer for rx */
    {
      dprintf("[tse_sgdma_read_init] Fatal error: No free packet buffers for RX\n");
      tse_ptr->netp->n_mib->ifInDiscards++;
      
      return ENP_NOBUFFER;
    }

    // ensure bit-31 of tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_buff is clear before passing
    // to SGDMA Driver
    uncached_packet_payload = (alt_u32 *)alt_remap_cached ((volatile void*) tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_buff, 4);

      alt_avalon_sgdma_construct_stream_to_mem_desc(
            (alt_sgdma_descriptor *) &tse_ptr->desc[tse_ptr->chain_loop+ALTERA_TSE_FIRST_RX_SGDMA_DESC_OFST],  // descriptor I want to work with
            (alt_sgdma_descriptor *) &tse_ptr->desc[tse_ptr->chain_loop+ALTERA_TSE_SECOND_RX_SGDMA_DESC_OFST],  // pointer to "next"
            uncached_packet_payload,            // tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_buff,                     // starting write_address
            0,                                  // read until EOP
            0);          // don't write to constant address


    } // for loop    


  printf("[tse_sgdma_read_init] RX descriptor chain desc (%d depth) created\n", 
    tse_ptr->chain_loop);
    
  tse_ptr->currdescriptor_ptr =  &tse_ptr->desc[ALTERA_TSE_FIRST_RX_SGDMA_DESC_OFST];
  tse_ptr->nextdescriptor_ptr = (alt_sgdma_descriptor *) IORD_ALTERA_TSE_SGDMA_DESC_NEXT(tse_ptr->currdescriptor_ptr);

  tse_ptr->desc_pointer = tse_ptr->currdescriptor_ptr;
  tse_ptr->chain_loop = 0;

  tse_mac_aRxRead( &tse_ptr->mi, tse_ptr->currdescriptor_ptr);
  
#if ALTERA_TSE_QOS_TIMER_OPTION  
    tse_ptr->alarmflags|=ALARM_ENABLE;
#endif  

  return SUCCESS;
}



/* @Function Description -  TSE Driver SGDMA RX ISR callback function
 *                          
 * 
 * @API TYPE        - callback internal function
 * @return SUCCESS on success
 */
int tse_mac_rcv(ins_tse_info* tse_ptr)
{     
  struct ethhdr * eth;
  int pklen;
  PACKET pkt;
  alt_u32 *uncached_packet_payload;
  alt_u8 tempVar;

  tse_ptr->desc_pointer = tse_ptr->currdescriptor_ptr;
#if ALTERA_TSE_QOS_TIMER_OPTION  
    tse_ptr->alarmflags&=~ALARM_ENABLE;
#endif
       
  for(; tse_ptr->chain_loop < ALTERA_TSE_SGDMA_RX_DESC_CHAIN_SIZE; tse_ptr->chain_loop++)
  {  
    if ((IORD_ALTERA_TSE_SGDMA_DESC_STATUS(tse_ptr->desc_pointer)) & 
         ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_TERMINATED_BY_EOP_MSK) {

      tse_ptr->desc_pointer->status&=~ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_TERMINATED_BY_EOP_MSK;

      pklen = IORD_ALTERA_TSE_SGDMA_DESC_ACTUAL_BYTES_TRANSFERRED(tse_ptr->desc_pointer);
    
      tse_ptr->nextdescriptor_ptr = (alt_sgdma_descriptor *)IORD_ALTERA_TSE_SGDMA_DESC_NEXT(tse_ptr->desc_pointer);
 
      pklen -= 2; /* correct frame length to the real length (note: this is different from TX side) */

      tse_ptr->netp->n_mib->ifInOctets += (u_long)pklen;
       
      tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_prot = tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_buff + ETHHDR_SIZE;
      tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_plen = pklen - 14;
      tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_tstamp = cticks;
      tse_ptr->pkt_array[tse_ptr->chain_loop]->net = tse_ptr->netp;
    
      // set packet type for demux routine
      eth = (struct ethhdr *)(tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_buff + ETHHDR_BIAS);
      tse_ptr->pkt_array[tse_ptr->chain_loop]->type = eth->e_type;
    
           
      
      if ((IORD_ALTERA_TSE_SGDMA_DESC_STATUS(tse_ptr->desc_pointer) & ( ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_E_CRC_MSK | ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_E_PARITY_MSK | ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_E_OVERFLOW_MSK |ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_E_SYNC_MSK | ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_E_UEOP_MSK | ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_E_MEOP_MSK | ALTERA_AVALON_SGDMA_DESCRIPTOR_STATUS_E_MSOP_MSK )) == 0)
      {
          pkt = pk_alloc(ALTERA_TSE_PKT_INIT_LEN + 4);
          if (!pkt)   /* couldn't get a free buffer for rx */
          {
            dprintf("No free buffers for rx\n");
            tse_ptr->netp->n_mib->ifInDiscards++;
          }
    
          else {
            putq(&rcvdq, tse_ptr->pkt_array[tse_ptr->chain_loop]);
            tse_ptr->pkt_array[tse_ptr->chain_loop] = pkt;
          }
      }      
             
      // ensure bit-31 of tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_buff is clear before passing
      // to SGDMA Driver
      uncached_packet_payload = (alt_u32 *)alt_remap_cached ((volatile void*) tse_ptr->pkt_array[tse_ptr->chain_loop]->nb_buff, 4);
      
      tempVar = IORD_8DIRECT(&tse_ptr->nextdescriptor_ptr->control, 0 );
      
      alt_avalon_sgdma_construct_stream_to_mem_desc(
            (alt_sgdma_descriptor *) &tse_ptr->desc[tse_ptr->chain_loop+ALTERA_TSE_FIRST_RX_SGDMA_DESC_OFST],  // descriptor I want to work with
            (alt_sgdma_descriptor *) &tse_ptr->desc[tse_ptr->chain_loop+ALTERA_TSE_SECOND_RX_SGDMA_DESC_OFST],  // pointer to "next"
            uncached_packet_payload,            // starting write_address
            0,                                  // read until EOP
            0);          // don't write to constant address

      IOWR_8DIRECT(&tse_ptr->nextdescriptor_ptr->control, 0, tempVar);

      tse_ptr->desc_pointer = tse_ptr->nextdescriptor_ptr;
    } /* if (descriptor terminated by EOP) */
    else
    {  
#if ALTERA_TSE_QOS_TIMER_OPTION  
    tse_ptr->alarmflags|=ALARM_ENABLE;
#endif
        break;
    }
   } /* for (descriptor chain) */    

#if ALTERA_TSE_QOS_TIMER_OPTION  
    tse_ptr->alarmflags|=ALARM_ENABLE;
#endif

  return SUCCESS;
} 



int tse_mac_stats(void * pio, int iface)
{
   ns_printf(pio, "tse_mac_stats(), stats will be added later!\n");
   return SUCCESS;
}



/* @Function Description -  Closing the TSE MAC Driver Interface
 *                          
 * 
 * @API TYPE - Public
 * @param  iface    index of the NET interface associated with the TSE MAC.
 * @return SUCCESS
 */

int tse_mac_close(int iface)
{
  int err;
  int state;
   
  /* status = down */
  nets[iface]->n_mib->ifAdminStatus = ALTERA_TSE_ADMIN_STATUS_DOWN;    

  /* disable the interrupt in the OS*/
  err = alt_irq_register (tse[iface].interruptNR, 0, NULL);
  if (err) 
  {  
    dprintf("Could not unregister interrupts, error = %d\n",err);
    return err;
  }
   
  /* Disable Receive path on the device*/
  state = IORD_ALTERA_TSEMAC_CMD_CONFIG(tse[iface].mi.base);
  IOWR_ALTERA_TSEMAC_CMD_CONFIG(tse[iface].mi.base,state & ~ALTERA_TSEMAC_CMD_RX_ENA_MSK); 
  
  /* status = down */                                     
  nets[iface]->n_mib->ifOperStatus = ALTERA_TSE_ADMIN_STATUS_DOWN;     

  return SUCCESS;
}



#endif
